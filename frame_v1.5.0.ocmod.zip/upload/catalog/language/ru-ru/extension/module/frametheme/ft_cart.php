<?php
// Text
$_['ft_heading_title']  = 'Корзина покупок';
$_['ft_text_empty']     = 'Ваша корзина пуста!';
$_['ft_text_cart']      = 'Перейти в корзину';
$_['ft_text_checkout']  = 'Оформить заказ';
$_['ft_text_recurring'] = 'Платежный профиль';
$_['ft_text_continue']  = 'Вернуться';