<?php
// Text
$_['text_show_map'] 	= 'Показать / скрыть карту';
$_['text_open_link'] = 'Открыть в Google Картах';
$_['text_close_map'] = 'Свернуть карту';
$_['text_title'] = 'Мы на карте';
$_['text_app'] = 'Навигация';
