<?php
$_['ft_heading_title']         = 'Контакты';
$_['ft_contacts_tab']          = 'Контакты';
$_['ft_callback_tab']          = 'Перезвоните мне';
$_['ft_text_more']             = 'Показать больше';
$_['ft_text_comment']          = 'Комментарий...';
$_['ft_entry_name']            = 'Ваше имя *';
$_['ft_entry_phone']           = 'Ваш телефон *';
$_['ft_entry_comment']         = 'Напишите комментарий';
$_['ft_text_send_button']      = 'Отправить заявку';


$_['ft_text_success']          = 'Ваша заявка отправлена!';
$_['ft_error_name']            = 'Введите имя (от 2 до 32 символов)';
$_['ft_error_phone']           = 'Введите корректный номер телефона';

$_['ft_text_mail_subject']     = '%s просит перезвонить';
$_['ft_text_mail_message'] 		= 'Имя: %s<br>Телефон: %s';
$_['ft_text_message_comment']  = '<br>Комментарий: %s';
