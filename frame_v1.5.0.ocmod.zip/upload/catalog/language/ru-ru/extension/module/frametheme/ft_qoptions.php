<?php
// Text
$_['text_option']              = 'Опции';
$_['button_cart']              = 'В корзину';


$_['text_error']               = 'Товар не найден!';
$_['text_back']           		 = 'Вернуться';
$_['text_not_found']           = 'Ошибка!';
