<?php
// Text
$_['text_search'] = 'Поиск в каталоге';
$_['text_anywhere'] = 'Везде';

$_['text_no_results'] = 'Нет совпадений';
$_['text_all_results'] = 'Все результаты';

$_['text_connection_error'] = 'Что то пошло не так :(';
