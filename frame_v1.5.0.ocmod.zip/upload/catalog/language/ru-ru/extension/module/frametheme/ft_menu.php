<?php
// Text
$_['text_category'] = 'Каталог';
$_['text_all'] = 'Показать все';
