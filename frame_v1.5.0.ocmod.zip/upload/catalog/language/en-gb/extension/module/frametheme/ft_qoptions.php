<?php
// Text
$_['text_option']              = 'Options:';
$_['button_cart']              = 'Add to Cart';


$_['text_error']               = 'Product not found!';
$_['text_back']           		 = 'Close';
$_['text_not_found']           = 'Error!';
