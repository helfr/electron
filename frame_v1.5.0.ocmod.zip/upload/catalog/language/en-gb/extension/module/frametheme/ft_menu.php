<?php
// Text
$_['text_category'] = 'Catalog';
$_['text_all'] = 'Show All';
