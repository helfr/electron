<?php
// Text
$_['text_show_map'] 	= 'Show / turn map';
$_['text_open_link'] = 'Open in Google Maps';
$_['text_close_map'] = 'Turn map';
$_['text_title'] = 'We are on the map';
$_['text_app'] = 'Open in App';
