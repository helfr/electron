<?php
// Text
$_['text_search'] = 'Search';
$_['text_anywhere'] = 'Anywhere';

$_['text_no_results'] = 'No results';
$_['text_all_results'] = 'All results';

$_['text_connection_error'] = 'Something went wrong :(';
