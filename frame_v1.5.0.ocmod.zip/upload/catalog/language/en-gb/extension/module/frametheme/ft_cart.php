<?php
// Text
$_['ft_heading_title']  = 'Shopping Сart';
$_['ft_text_empty']     = 'Cart is empty!';
$_['ft_text_cart']      = 'Go to Shopping Сart';
$_['ft_text_checkout']  = 'Checkout';
$_['ft_text_recurring'] = 'Payment profile';
$_['ft_text_continue']  = 'Back';